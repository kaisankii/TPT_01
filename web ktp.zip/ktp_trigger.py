"""
Menjalankan pembacaan KTP hanya saat ada tugas dari server (tombol di web registrasi).
Taruh di folder edge_ktp, lalu jalankan dari CMD di folder itu:

    set CSMS_URL=https://HOST-NGROK
    set CSMS_API_KEY=ISI_API_KEY
    python ktp_trigger.py

Saat tidak ada tugas, kamera mati dan hanya ada satu pengecekan ringan tiap 2 detik.
Anggapan: event KTP di output/events.jsonl punya field "nik" (cocokkan dengan EVENT_SCHEMA.md).
"""
import json
import os
import subprocess
import sys
import time

import requests

BASE = os.environ["CSMS_URL"].rstrip("/")
HEAD = {"X-API-Key": os.environ["CSMS_API_KEY"], "ngrok-skip-browser-warning": "true"}
CMD = [sys.executable, "ktp_main.py", "--source", "0", "--width", "1280", "--height", "720"]
EVENTS = os.path.join("output", "events.jsonl")
JEDA = 2


def cari_nik(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if k.lower() == "nik" and isinstance(v, str):
                return v
            r = cari_nik(v)
            if r:
                return r
    elif isinstance(o, list):
        for v in o:
            r = cari_nik(v)
            if r:
                return r
    return None


def kerjakan(tugas):
    os.makedirs("output", exist_ok=True)
    awal = os.path.getsize(EVENTS) if os.path.exists(EVENTS) else 0
    pos = awal
    batas = time.time() + tugas["sisa_detik"]
    proc = subprocess.Popen(CMD)
    try:
        while time.time() < batas and proc.poll() is None:
            time.sleep(0.5)
            if not os.path.exists(EVENTS) or os.path.getsize(EVENTS) <= pos:
                continue
            with open(EVENTS, "rb") as f:
                f.seek(pos)
                data = f.read()
                pos = f.tell()
            for baris in data.decode("utf-8", "ignore").splitlines():
                try:
                    nik = cari_nik(json.loads(baris))
                except ValueError:
                    continue
                if not nik:
                    continue
                r = requests.post(BASE + "/api/v1/ktp/hasil", headers=HEAD, timeout=5,
                                  json={"id_tugas": tugas["id_tugas"], "nik": nik}).json()
                print("hasil:", r.get("hasil"))
                if r.get("hasil") in ("cocok", "tugas_tidak_aktif"):
                    return
    finally:
        proc.terminate()
        proc.wait()
        if os.path.exists(EVENTS):   # buang baris event (berisi NIK) yang baru dibaca
            with open(EVENTS, "rb+") as f:
                f.truncate(min(awal, os.path.getsize(EVENTS)))


print("Menunggu tugas KTP dari server (kamera mati)...")
while True:
    try:
        t = requests.get(BASE + "/api/v1/ktp/tugas", headers=HEAD, timeout=5).json().get("tugas")
    except (requests.RequestException, ValueError):
        t = None
    if t:
        print("Tugas masuk, kamera aktif", t["sisa_detik"], "detik")
        kerjakan(t)
    time.sleep(JEDA)
