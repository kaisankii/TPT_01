"""
Verifikasi KTP lewat tombol di web registrasi. Jalankan dari folder csms:
    python3 upgrade_ktp.py
Mengubah main.py dan static/daftar.html (cadangan: *.ktp.bak). Dikembalikan otomatis kalau error.
"""
import os
import shutil
import subprocess
import sys

if not (os.path.exists("main.py") and os.path.exists("static/daftar.html")):
    sys.exit("Jalankan dari folder csms (berisi main.py dan static/daftar.html).")
M = open("main.py", encoding="utf-8").read()
H = open("static/daftar.html", encoding="utf-8").read()
if "ktp_tugas" in M or "tampilkanKTP" in H:
    sys.exit("Sudah pernah dipasang. Tidak ada yang dilakukan.")

LAMA_M = '''    return {"status": "pending", "akun_baru": akun_baru, "kendaraan": hasil}'''
BARU_M = '''    token = buat_tugas_ktp(id_user, daftar)
    return {"status": "pending", "akun_baru": akun_baru, "kendaraan": hasil, "ktp_token": token}'''

TAMBAHAN = '''import secrets


# ---------------------------------------------------------------- verifikasi KTP (tombol di web)
KTP_TOKEN_MENIT = 15   # tombol boleh ditekan sampai sekian menit setelah mendaftar
KTP_SCAN_DETIK = 90    # kamera KTP aktif sekian detik setelah tombol ditekan
KTP_MAKS_COBA = 3      # NIK tidak cocok maksimal sekian kali per pendaftaran


def _init_ktp():
    con = koneksi()
    con.execute("CREATE TABLE IF NOT EXISTS ktp_tugas (id_tugas TEXT PRIMARY KEY, id_pengguna TEXT NOT NULL, "
                "token TEXT UNIQUE NOT NULL, kendaraan_ids TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'siap', "
                "token_exp TEXT NOT NULL, scan_exp TEXT, percobaan INTEGER NOT NULL DEFAULT 0)")
    con.commit()
    con.close()


_init_ktp()


def _efektif(status, scan_exp):
    if status == "menunggu" and (not scan_exp or scan_exp < iso(sekarang())):
        return "habis"
    return status


def buat_tugas_ktp(id_user, daftar_plat):
    """Dipanggil setelah registrasi. Mengembalikan token untuk tombol verifikasi, atau None."""
    con = koneksi()
    try:
        ids = []
        for plat in daftar_plat:
            r = con.execute("SELECT id_kendaraan FROM kendaraan WHERE plat_key=? AND id_pengguna=? "
                            "AND status_verifikasi='pending'", (plate_key(plat), id_user)).fetchone()
            if r:
                ids.append(r[0])
        if not ids:
            return None
        token = secrets.token_urlsafe(18)
        con.execute("INSERT INTO ktp_tugas (id_tugas, id_pengguna, token, kendaraan_ids, token_exp) "
                    "VALUES (?,?,?,?,?)", (str(uuid.uuid4()), id_user, token, ",".join(ids),
                                           iso(sekarang() + timedelta(minutes=KTP_TOKEN_MENIT))))
        con.commit()
        return token
    finally:
        con.close()


class MulaiKTP(BaseModel):
    token: str


@app.post("/api/v1/ktp/mulai")
def ktp_mulai(b: MulaiKTP):
    """Dipanggil tombol di web registrasi: membuka jendela baca KTP."""
    con = koneksi()
    try:
        con.execute("BEGIN IMMEDIATE")
        t = con.execute("SELECT id_tugas, status, token_exp, scan_exp FROM ktp_tugas WHERE token=?",
                        (b.token,)).fetchone()
        if not t:
            raise HTTPException(404, "Tautan verifikasi tidak ditemukan")
        st = _efektif(t[1], t[3])
        if st in ("berhasil", "gagal", "menunggu"):
            return {"status": st}
        if t[2] < iso(sekarang()):
            raise HTTPException(410, "Waktu verifikasi habis. Hubungi petugas")
        sibuk = con.execute("SELECT 1 FROM ktp_tugas WHERE status='menunggu' AND scan_exp>? AND id_tugas<>?",
                            (iso(sekarang()), t[0])).fetchone()
        if sibuk:
            raise HTTPException(409, "Kamera KTP sedang dipakai orang lain. Coba lagi sebentar")
        con.execute("UPDATE ktp_tugas SET status='menunggu', scan_exp=? WHERE id_tugas=?",
                    (iso(sekarang() + timedelta(seconds=KTP_SCAN_DETIK)), t[0]))
        con.commit()
        return {"status": "menunggu", "detik": KTP_SCAN_DETIK}
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


@app.get("/api/v1/ktp/status/{token}")
def ktp_status(token: str):
    con = koneksi()
    try:
        t = con.execute("SELECT status, scan_exp FROM ktp_tugas WHERE token=?", (token,)).fetchone()
    finally:
        con.close()
    if not t:
        raise HTTPException(404, "Tautan verifikasi tidak ditemukan")
    st = _efektif(t[0], t[1])
    sisa = 0
    if st == "menunggu":
        sisa = max(0, int((datetime.fromisoformat(t[1]) - sekarang()).total_seconds()))
    return {"status": st, "sisa_detik": sisa}


@app.get("/api/v1/ktp/tugas", dependencies=[Depends(cek_kunci)])
def ktp_tugas():
    """Dicek edge device secara berkala. Kamera KTP hanya perlu menyala kalau ada tugas."""
    con = koneksi()
    try:
        t = con.execute("SELECT id_tugas, scan_exp FROM ktp_tugas WHERE status='menunggu' AND scan_exp>? "
                        "ORDER BY scan_exp LIMIT 1", (iso(sekarang()),)).fetchone()
    finally:
        con.close()
    if not t:
        return {"tugas": None}
    sisa = max(0, int((datetime.fromisoformat(t[1]) - sekarang()).total_seconds()))
    return {"tugas": {"id_tugas": t[0], "sisa_detik": sisa}}


class HasilKTP(BaseModel):
    id_tugas: str
    nik: str


@app.post("/api/v1/ktp/hasil", dependencies=[Depends(cek_kunci)])
def ktp_hasil(b: HasilKTP):
    """Edge mengirim NIK hasil baca. NIK dibandingkan lewat hash, tidak disimpan dan tidak dicatat."""
    nik = b.nik.strip()
    if not (nik.isdigit() and len(nik) == 16):
        return {"hasil": "nik_tidak_valid"}
    con = koneksi()
    try:
        con.execute("BEGIN IMMEDIATE")
        t = con.execute("SELECT t.status, t.scan_exp, t.percobaan, t.kendaraan_ids, p.nik_hash "
                        "FROM ktp_tugas t JOIN pengguna p ON p.id_pengguna=t.id_pengguna "
                        "WHERE t.id_tugas=?", (b.id_tugas,)).fetchone()
        if not t:
            raise HTTPException(404, "Tugas tidak ditemukan")
        if _efektif(t[0], t[1]) != "menunggu":
            return {"hasil": "tugas_tidak_aktif"}
        if hmac.compare_digest(hash_nik(nik), t[4]):
            ids = t[3].split(",")
            con.execute("UPDATE kendaraan SET status_verifikasi='terverifikasi', tgl_verifikasi=? "
                        "WHERE id_kendaraan IN (%s)" % ",".join("?" * len(ids)), [iso(sekarang())] + ids)
            con.execute("UPDATE ktp_tugas SET status='berhasil' WHERE id_tugas=?", (b.id_tugas,))
            hasil = {"hasil": "cocok"}
        else:
            n = t[2] + 1
            con.execute("UPDATE ktp_tugas SET percobaan=?, status=? WHERE id_tugas=?",
                        (n, "gagal" if n >= KTP_MAKS_COBA else "menunggu", b.id_tugas))
            hasil = {"hasil": "tidak_cocok", "sisa_percobaan": max(0, KTP_MAKS_COBA - n)}
        con.commit()
        return hasil
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
'''

JS = r"""function tampilkanKTP(token) {
  const kotak = document.createElement('div');
  kotak.className = 'info';
  const teks = document.createElement('p');
  teks.textContent = 'Verifikasi KTP: berdiri di dekat kamera KTP di SPKLU, lalu tekan tombol. Kamera hanya aktif setelah tombol ditekan.';
  const tombol = document.createElement('button');
  tombol.type = 'button';
  tombol.textContent = 'Verifikasi KTP sekarang';
  const info = document.createElement('p');
  kotak.append(teks, tombol, info);
  hasil.appendChild(kotak);
  let timer = null;
  const set = (kelas, isi) => { info.className = kelas; info.textContent = isi; };
  async function cek() {
    try {
      const s = await (await fetch('/api/v1/ktp/status/' + encodeURIComponent(token))).json();
      if (s.status === 'menunggu') { set('', 'Kamera aktif. Tunjukkan KTP dan tahan 2-3 detik (' + s.sisa_detik + ' detik).'); return; }
      clearInterval(timer);
      if (s.status === 'berhasil') { tombol.style.display = 'none'; set('ok', 'KTP terverifikasi. Terima kasih.'); }
      else if (s.status === 'gagal') { tombol.style.display = 'none'; set('err', 'Data KTP tidak cocok dengan data pendaftaran. Hubungi petugas.'); }
      else { tombol.disabled = false; set('err', 'Waktu habis. Tekan tombol untuk mencoba lagi.'); }
    } catch (e) {}
  }
  tombol.addEventListener('click', async () => {
    tombol.disabled = true;
    set('', 'Mengaktifkan kamera...');
    try {
      const r = await fetch('/api/v1/ktp/mulai', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({token: token})});
      const d = await r.json();
      if (!r.ok) { tombol.disabled = false; set('err', d.detail); return; }
    } catch (e) { tombol.disabled = false; set('err', 'Tidak bisa terhubung ke server.'); return; }
    clearInterval(timer);
    timer = setInterval(cek, 2000);
    cek();
  });
}
"""

ANCHOR_SUBMIT = "form.addEventListener('submit', async (e) => {"
ANCHOR_CAT = "hasil.appendChild(cat);"


def ganti(teks, lama, baru):
    if teks.count(lama) != 1:
        sys.exit("TIDAK COCOK, tidak ada yang diubah. Bagian ini tidak ditemukan persis satu kali:\n\n" + lama)
    return teks.replace(lama, baru)


M2 = ganti(M, LAMA_M, BARU_M).rstrip() + "\n\n\n" + TAMBAHAN
H2 = ganti(H, ANCHOR_SUBMIT, JS + "\n" + ANCHOR_SUBMIT)
H2 = ganti(H2, ANCHOR_CAT, ANCHOR_CAT + "\n      if (d.ktp_token) tampilkanKTP(d.ktp_token);")

shutil.copy("main.py", "main.py.ktp.bak")
shutil.copy("static/daftar.html", "static/daftar.html.ktp.bak")
open("main.py", "w", encoding="utf-8").write(M2)
open("static/daftar.html", "w", encoding="utf-8").write(H2)
if subprocess.run([sys.executable, "-m", "py_compile", "main.py"]).returncode != 0:
    shutil.copy("main.py.ktp.bak", "main.py")
    shutil.copy("static/daftar.html.ktp.bak", "static/daftar.html")
    sys.exit("Hasil perubahan error, semua file dikembalikan seperti semula.")
print("Selesai. Restart aplikasi, lalu coba daftar: tombol Verifikasi KTP muncul setelah pendaftaran berhasil.")
