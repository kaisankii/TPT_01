"""
Tambah panel "Verifikasi KTP" di halaman monitor (tanpa menampilkan NIK).
Jalankan dari folder csms, SETELAH upgrade_csms.py dan upgrade_ktp.py:
    python3 upgrade_monitor_ktp.py
"""
import os
import shutil
import subprocess
import sys

if not (os.path.exists("main.py") and os.path.exists("static/monitor.html")):
    sys.exit("Jalankan dari folder csms (berisi main.py dan static/monitor.html).")
M = open("main.py", encoding="utf-8").read()
H = open("static/monitor.html", encoding="utf-8").read()
if "ktp_tugas" not in M:
    sys.exit("Jalankan upgrade_ktp.py dulu.")
if '"ktp": [' in M:
    sys.exit("Sudah pernah dipasang. Tidak ada yang dilakukan.")


def ganti(teks, lama, baru):
    if teks.count(lama) != 1:
        sys.exit("TIDAK COCOK, tidak ada yang diubah. Bagian ini tidak ditemukan persis satu kali:\n\n" + lama)
    return teks.replace(lama, baru)


M2 = ganti(M, '"ORDER BY waktu_akses DESC LIMIT 15").fetchall()', '''"ORDER BY waktu_akses DESC LIMIT 15").fetchall()
        ktp = con.execute(
            "SELECT t.status, t.scan_exp, t.token_exp, t.percobaan, "
            "(SELECT group_concat(k.plat_nomor, ', ') FROM kendaraan k "
            "WHERE instr(',' || t.kendaraan_ids || ',', ',' || k.id_kendaraan || ',') > 0) "
            "FROM ktp_tugas t ORDER BY t.token_exp DESC LIMIT 8").fetchall()''')
M2 = ganti(M2, '"diperbarui": iso(sekarang())}', '''"ktp": [{"waktu": iso(datetime.fromisoformat(r[2]) - timedelta(minutes=KTP_TOKEN_MENIT)),
                     "status": _efektif(r[0], r[1]), "percobaan": r[3], "plat": r[4]} for r in ktp],
            "diperbarui": iso(sekarang())}''')

H2 = ganti(H, "</main>", '''  <h2>Verifikasi KTP</h2>
  <div class="wrap">
    <table>
      <thead><tr><th>Waktu</th><th>Plat</th><th>Status</th></tr></thead>
      <tbody id="ktp"></tbody>
    </table>
  </div>
</main>''')
H2 = ganti(H2, "tb.append(tr);\n    });", r'''tb.append(tr);
    });

    const STATUS = {menunggu: ["Menunggu KTP dibaca", "warn"], berhasil: ["Terverifikasi", "ok"],
      gagal: ["Terkunci", "alert"], habis: ["Waktu habis", "warn"], siap: ["Tombol belum ditekan", ""]};
    const tk = $("#ktp");
    tk.replaceChildren();
    (d.ktp || []).forEach(k => {
      const [teks, kelas] = STATUS[k.status] || [k.status, ""];
      const tr = el("tr");
      tr.append(el("td", "", new Date(k.waktu).toLocaleTimeString("id-ID")));
      tr.append(el("td", "", k.plat || "-"));
      tr.append(el("td", kelas, teks + (k.percobaan ? " (" + k.percobaan + " kali tidak cocok)" : "")));
      tk.append(tr);
    });''')

shutil.copy("main.py", "main.py.mon.bak")
shutil.copy("static/monitor.html", "static/monitor.html.mon.bak")
open("main.py", "w", encoding="utf-8").write(M2)
open("static/monitor.html", "w", encoding="utf-8").write(H2)
if subprocess.run([sys.executable, "-m", "py_compile", "main.py"]).returncode != 0:
    shutil.copy("main.py.mon.bak", "main.py")
    shutil.copy("static/monitor.html.mon.bak", "static/monitor.html")
    sys.exit("Hasil perubahan error, semua file dikembalikan seperti semula.")
print("Selesai. Restart aplikasi, lalu muat ulang /monitor.")
